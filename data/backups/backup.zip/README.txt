Old backup from the 2019 migration.
